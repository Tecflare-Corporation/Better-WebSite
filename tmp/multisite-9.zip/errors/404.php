<?php
if (!isset($testmode))
{
include("theme/head.php");
?>
<h1>404 File Not Found</h1>
<p>You are probably lost. The file cannot be found.</p>
<?php
include("theme/footer.php");
}
?>