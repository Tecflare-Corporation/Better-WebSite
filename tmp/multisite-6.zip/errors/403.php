<?php
if (!isset($testmode))
{
include("theme/head.php");
?>
<h1>403 Access Forbidden</h1>
<p>You do not have access to the resource.</p>
<?php
include("theme/footer.php");
}
?>