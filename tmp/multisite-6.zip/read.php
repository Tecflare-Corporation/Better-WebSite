<?php
include ("errors/" . $_GET["error"] . ".php");
?>