<div class="container">
  <section>
    <div class="page-header">
    
      <div class="pull-right">
        <div class="btn-group">
          <button class="btn btn-primary">
            <a href="admin/account.php"><?php echo $_SESSION["usename"]; ?></a>
          </button>
          <button class="btn btn-primary dropdown-toggle">
            <a href="admin/do.php?value=exit">Exit</a>
          </button>
  </section>
</div>